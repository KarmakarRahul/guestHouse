import React, { useState } from 'react';
import './index.css';
import logo from './cimfr-logo.jpg';
import { useNavigate, Link } from "react-router-dom"

const Navbar = () => {
  const [isChecked, setIsChecked] = useState(false);

  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
  };

  return (
    <header>
      <div className="container">
        <input type="checkbox" id="check" checked={isChecked} onChange={handleCheckboxChange} />
        <div className="logo-container">
        <img src={logo} alt="" />
          <h3 className="logo">CIMFR <span>Guesthouse</span></h3>
        </div>

        <div className="nav-btn">
          <div className="nav-links">
            <ul>
              <li className="nav-link" style={{ '--i': '.6s' }}>
              <Link to="/">Home</Link>
              </li>
              {/* <li className="nav-link" style={{ '--i': '.85s' }}>
                <a href="#">Menu<i className="fas fa-caret-down"></i></a>
                <div className="dropdown">
                  <ul>
                    <li className="dropdown-link">
                      <a href="#">Link 1</a>
                    </li>
                    <li className="dropdown-link">
                      <a href="#">Link 2</a>
                    </li>
                    <li className="dropdown-link">
                      <a href="#">Link 3<i className="fas fa-caret-down"></i></a>
                      <div className="dropdown second">
                        <ul>
                          <li className="dropdown-link">
                            <a href="#">Link 1</a>
                          </li>
                          <li className="dropdown-link">
                            <a href="#">Link 2</a>
                          </li>
                          <li className="dropdown-link">
                            <a href="#">Link 3</a>
                          </li>
                          <li className="dropdown-link">
                            <a href="#">More<i className="fas fa-caret-down"></i></a>
                            <div className="dropdown second">
                              <ul>
                                <li className="dropdown-link">
                                  <a href="#">Link 1</a>
                                </li>
                                <li className="dropdown-link">
                                  <a href="#">Link 2</a>
                                </li>
                                <li className="dropdown-link">
                                  <a href="#">Link 3</a>
                                </li>
                                <div className="arrow"></div>
                              </ul>
                            </div>
                          </li>
                          <div className="arrow"></div>
                        </ul>
                      </div>
                    </li>
                    <li className="dropdown-link">
                      <a href="#">Link 4</a>
                    </li>
                    <div className="arrow"></div>
                  </ul>
                </div>
              </li> */}
              {/* <li className="nav-link" style={{ '--i': '1.1s' }}>
                <a href="#">Services<i className="fas fa-caret-down"></i></a>
                <div className="dropdown">
                  <ul>
                    <li className="dropdown-link">
                      <a href="#">Link 1</a>
                    </li>
                    <li className="dropdown-link">
                      <a href="#">Link 2</a>
                    </li>
                    <li className="dropdown-link">
                      <a href="#">Link 3<i className="fas fa-caret-down"></i></a>
                      <div className="dropdown second">
                        <ul>
                          <li className="dropdown-link">
                            <a href="#">Link 1</a>
                          </li>
                          <li className="dropdown-link">
                            <a href="#">Link 2</a>
                          </li>
                          <li className="dropdown-link">
                            <a href="#">Link 3</a>
                          </li>
                          <li className="dropdown-link">
                            <a href="#">More<i className="fas fa-caret-down"></i></a>
                            <div className="dropdown second">
                              <ul>
                                <li className="dropdown-link">
                                  <a href="#">Link 1</a>
                                </li>
                                <li className="dropdown-link">
                                  <a href="#">Link 2</a>
                                </li>
                                <li className="dropdown-link">
                                  <a href="#">Link 3</a>
                                </li>
                                <div className="arrow"></div>
                              </ul>
                            </div>
                          </li>
                          <div className="arrow"></div>
                        </ul>
                      </div>
                    </li>
                    <li className="dropdown-link">
                      <a href="#">Link 4</a>
                    </li>
                    <div className="arrow"></div>
                  </ul>
                </div>
              </li> */}
              <li className="nav-link" style={{ '--i': '.85s' }}>
              <Link to="/register">Guest Registration</Link>
              </li>
              <li className="nav-link" style={{ '--i': '1.1s' }}>
                <a href="#">View Rooms</a>
              </li>
              <li className="nav-link" style={{ '--i': '1.20s' }}>
                <a href="#">Booking Status</a>
              </li>
              <li className="nav-link" style={{ '--i': '1.35s' }}>
                <a href="#">About</a>
              </li>
            </ul>
          </div>
        </div>
          <div className="log-sign" style={{ '--i': '1.8s' }}>
          <Link to="/login" className="btn transparent">Login in</Link>
          </div>

        <div className="hamburger-menu-container">
          <div className="hamburger-menu">
            <div></div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
